Icons from Bootstrap Icons (https://github.com/twbs/icons), licensed under the MIT License. See LICENSE in this directory.
