import {QuestionnaireScreen} from './questionnaire.js';
import {QuestionnairesScreen} from './questionnaires.js';
import {escapeHTML as e,Button} from '../components.js';
export const screens={
 'questionnaire':{title:'Edit questionnaire',render:QuestionnaireScreen},
 'questionnaires':{title:'Questionnaires',render:QuestionnairesScreen},
};
export function registerScreen(id,{title,render}){screens[id]={title,render};}
export function PendingScreen({title}){return `<section class="screen-empty"><h1>${e(title)}</h1><p class="muted">This screen hasn’t been added to the prototype yet.</p><a class="button" href="#/questionnaire">Back to questionnaire</a></section>`;}
