import {initialCategoryDraft} from './builder-model.js';
export const defaultAcknowledgement='By checking this box, I acknowledge that I understand and agree that the information I have provided on this questionnaire is true and accurate to the best of my knowledge. I also acknowledge that I have an obligation to inform {{company_name}} of any changes to this information in a timely manner.';
export const STORAGE_KEY = 'navex-disclosure-prototype-v1';
export function initialState() {
  const names = ['Advisory Organizations'];
  return {
    title:'Yearly Questionnaire v.2', status:'Draft', language:'English (US)',
    introduction:'Welcome to the yearly disclosure questionnaire. Please review each category and answer all required questions.',
    modelVersion:4, selected:'advisory-organizations', answers:{}, routing:{},
    description:'A disclosure questionnaire covering advisory organizations and Open Payments.',
    owner:'Collins, Janelle – janelle.collins@navex.com',estimatedMinutes:'',organizationName:'Sample Company',onDemand:false,disclosureRules:[],history:[],acknowledgement:defaultAcknowledgement,
    categories:names.map(name=>({id:name.toLowerCase().replaceAll('&','and').replace(/[^a-z0-9]+/g,'-'),name,disabled:false,required:true,description:'',question:''}))
  };
}
const categoryContent={
 'Advisory Organizations':{description:'While serving on an industry or advisory organization is often a benefit to our organization, a conflict of interest still may exist. Roles here could include serving as an advisory council member or officer of a professional or trade organization, or public or private standard or rule setting body applicable to the business and interests of Sample Company.',question:'Do you serve on any industry related advisory councils or groups including trade associations, vendor related organizations or similar entities?'},
 'Gifts & Entertainment':{description:'Gifts, entertainment, hospitality or other benefits offered to or received from suppliers, customers or business partners may create a conflict of interest with Sample Company.',question:'Have you given or received any gifts or entertainment involving a supplier, customer or business partner of Sample Company?'},
 'Outside Employment':{description:'Outside employment, consulting or other business activities may create a conflict of interest with your responsibilities at Sample Company.',question:'Do you have any outside employment or consulting activities that could conflict with your responsibilities at Sample Company?'}
};
export function upgradeQuestionnaire(data){
 if(data.modelVersion>=4)return data;
 if(data.modelVersion>=3){
  const removed=data.categories.filter(c=>c.name.startsWith('Gifts & Entertainment')||c.name==='Outside Employment').map(c=>c.id);
  const categories=data.categories.filter(c=>!removed.includes(c.id));
  const migrated={...data,modelVersion:4,categories:categories.length?categories:initialState().categories};
  migrated.answers=Object.fromEntries(Object.entries(data.answers||{}).filter(([id])=>!removed.includes(id)));
  migrated.routing=Object.fromEntries(Object.entries(data.routing||{}).filter(([id])=>!removed.includes(id)).map(([id,routes])=>[id,Object.fromEntries(Object.entries(routes).map(([answer,target])=>[answer,removed.includes(target)?'continue':target]))]));
  migrated.disclosureRules=(data.disclosureRules||[]).filter(rule=>!removed.includes(rule.categoryId));
  if(!migrated.categories.some(c=>c.id===migrated.selected))migrated.selected=migrated.categories[0].id;
  if(migrated.description==='A disclosure questionnaire covering advisory organizations, gifts and entertainment, and outside employment.')migrated.description=initialState().description;
  if(migrated.acknowledgement==='I acknowledge that the information provided in this questionnaire is accurate and complete.')migrated.acknowledgement=defaultAcknowledgement;
  return migrated;
 }
 if(data.modelVersion>=2)return upgradeQuestionnaire({...data,modelVersion:3,categories:data.categories.map(c=>{const sample=categoryContent[c.name];return {...c,description:sample&&c.description===sample.description?'':c.description,question:sample&&c.question===sample.question?'':c.question};})});
 const base=initialState(),old=data.categories||[];const remap={};
 const categories=base.categories.map(c=>{const match=old.find(x=>x.name===c.name||(c.name==='Gifts & Entertainment'&&x.name.startsWith('Gifts & Entertainment')));if(match)remap[match.id]=c.id;return {...c,...match,id:c.id,name:c.name,description:match?.description||c.description,question:match?.question||c.question};});
 const ids=new Set(categories.map(c=>c.id));const answers={},routing={};
 for(const [id,answer]of Object.entries(data.answers||{}))if(ids.has(remap[id]||id))answers[remap[id]||id]=answer;
 for(const [id,routes]of Object.entries(data.routing||{}))if(ids.has(remap[id]||id))routing[remap[id]||id]=Object.fromEntries(Object.entries(routes).map(([answer,target])=>[answer,ids.has(remap[target]||target)?remap[target]||target:['continue','complete'].includes(target)?target:'continue']));
 return upgradeQuestionnaire({...base,...data,modelVersion:2,categories,answers,routing,selected:ids.has(remap[data.selected]||data.selected)?remap[data.selected]||data.selected:categories[0].id});
}
export function loadState(storage) {
  try {
    const data=JSON.parse(storage.getItem(STORAGE_KEY));
    if (data && Array.isArray(data.categories) && data.categories.every(c=>c && typeof c.id==='string' && typeof c.name==='string') && data.categories.length && typeof data.title==='string') return upgradeQuestionnaire({...data});
  } catch {}
  return initialState();
}
export function moveCategory(state,id,offset) {
  const index=state.categories.findIndex(c=>c.id===id), next=index+offset;
  if(index<0 || next<0 || next>=state.categories.length) return false;
  [state.categories[index],state.categories[next]]=[state.categories[next],state.categories[index]];
  return true;
}
export function deleteCategory(state,id) {
  if(state.categories.length<=1)return false;
  const index=state.categories.findIndex(c=>c.id===id);
  if(index<0)return false;
  state.categories.splice(index,1);
  delete state.answers[id]; delete state.routing[id];
  state.disclosureRules=(state.disclosureRules||[]).filter(rule=>rule.categoryId!==id);
  for(const routes of Object.values(state.routing))for(const answer of Object.keys(routes))if(routes[answer]===id)routes[answer]='continue';
  if(state.selected===id)state.selected=state.categories[Math.min(index,state.categories.length-1)].id;
  return true;
}
export const disclosureCategoryNames=['Advisory Organizations','Board Participation','Financial Support or Loans','Government Participation','Gifts & Entertainment - Received','Gifts & Entertainment - Given','Outside Employment','Business Opportunities','Family Member Employment','Outside Investments','Relationships','Other','Open Payments'];
export function addCategory(state,name,{copyFrom}={}) {
  const clean=name.trim(); if(!clean)return null;
  const id=crypto.randomUUID();
  const category=copyFrom?{...structuredClone(copyFrom),id,name:clean}:{id,name:clean,description:'',question:'',required:true,disabled:false};
  if(clean==='Open Payments'){category.kind='open-payments';category.required=false;category.description=copyFrom?.description||'Review payment records reported through Open Payments.';category.question='';category.builder=initialCategoryDraft({...category,builder:copyFrom?.builder},id);}
  state.categories.push(category);
  state.selected=id;return id;
}
