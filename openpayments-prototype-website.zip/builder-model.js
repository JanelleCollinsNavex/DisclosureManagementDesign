export const choiceTypes=['Radiogroup','Dropdown','Checkbox'];
export function createField(type,id){return {id,type,title:type,required:true,...(choiceTypes.includes(type)?{options:['Item 1','Item 2','Item 3']}:{}),...(type==='Checkbox'?{selectAll:false}:{})};}
// A stable destination id keeps insertion correct when moving a card downward.
export function placeField(fields,field,beforeId=null){const remaining=fields.filter(f=>f.id!==field.id);const index=remaining.findIndex(f=>f.id===beforeId);remaining.splice(index<0?remaining.length:index,0,field);return remaining;}

export function setPrimaryQuestionType(field,type){if(field.id!=='primary'||!['Yes/No','OpenPayments'].includes(type))return false;field.type=type==='OpenPayments'?'OpenPayments':'Radiogroup';field.options=['Yes','No'];return true;}

export function initialCategoryDraft(category,categoryId){
 if(category?.builder){const draft=structuredClone(category.builder);if(category.description!==undefined)draft.introduction=category.description;return category.kind==='open-payments'?ensurePaymentSection(draft):draft;}
 if(category?.kind==='open-payments')return ensurePaymentSection({introduction:category.description||'',fields:[{id:'recipient-npi',type:'Singleline Input',title:'National Provider Identifier (NPI)',required:true},{id:'primary',type:'OpenPayments',title:category.question||'Review your Open Payments records',required:false}]});
 return null;
}

export const paymentSectionId='payment-followups';
export function ensurePaymentSection(draft){
 if(!draft.paymentSection){draft.paymentSection={id:paymentSectionId,title:'Open Payment Records'};for(const field of draft.fields)if(!['primary','recipient-npi','organizations'].includes(field.id)){field.sectionId=paymentSectionId;if(field.openPaymentsColumn)field.fillFromOpenPayments=true;}}
 if(draft.paymentSection.title==='Edit Header Text Here')draft.paymentSection.title='Open Payment Records';
 return draft;
}
export function setFillFromOpenPayments(field,enabled){field.fillFromOpenPayments=enabled;if(!enabled)delete field.openPaymentsColumn;}
export function assignPaymentSection(field,sectionId){if(sectionId&&(!['Singleline Input','Multiline Input'].includes(field.type)||['primary','recipient-npi'].includes(field.id)))return false;if(sectionId)field.sectionId=sectionId;else{delete field.sectionId;setFillFromOpenPayments(field,false);}return true;}
